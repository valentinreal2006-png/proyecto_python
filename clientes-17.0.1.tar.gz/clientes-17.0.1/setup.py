from setuptools import setup
setup(
    name="clientes",
    version="17.0.1",
    packages=["paquete_1"],
    install_requires=[],
    author="Valentin",
    author_email="pitureal2006@gmail.com",
    description="Un paquete de ejemplo para demostrar la estructura de paquetes en Python", 
)