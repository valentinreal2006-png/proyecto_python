class clientes:

    def __init__(self,nombre,apellido,dni):
        self.nombre = nombre
        self.apellido = apellido
        self.dni = dni
    
    def __str__(self):
        return f"Nombre:{self.nombre}\nApellido:{self.apellido}\nDNI:{self.dni}"
