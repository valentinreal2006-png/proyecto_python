def llamando_modulo_2():
    print("estoy usando el modulo 2")